package org.fda.commands;

import com.beust.jcommander.Parameter;
import com.beust.jcommander.Parameters;
import com.beust.jcommander.converters.FileConverter;
import java.io.File;
import org.fda.data.Enums;
import org.fda.data.Utilities;

/**
 *
 * @author Gokhan.Yavas
 */
@Parameters(commandDescription = "Recompute the model based on the model filter coefficient")
public class ShowModelCommand extends Command{
    @Parameter(names = {"-i"}, description = "Input model file", required = true, converter = FileConverter.class)            
    protected File inputFile;

    @Parameter(names = {"-s"}, description = "Show the model data", required = false)            
    protected boolean showModelData=Utilities.showModelData;

    @Parameter(names = {"-t"}, description = "Show in tabular format", required = false)            
    protected boolean intabularformat=Utilities.showModelInTabularFormat;

    public boolean isIntabularformat() {
        return intabularformat;
    }
    
    protected File destinationFolder=new File(System.getProperty("user.dir"));
    public ShowModelCommand(){
        this.rcmd = Enums.RunCommand.ShowModel;
    }
    public File getInputFile() {
        return inputFile;
    }
    public boolean getShowModelData() {
        return showModelData;
    }
    
}
