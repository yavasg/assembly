
package org.fda.commands;
import com.beust.jcommander.Parameter;
import com.beust.jcommander.Parameters;
import com.beust.jcommander.converters.FileConverter;
import java.io.File;
import org.fda.data.Enums.RunCommand;
/**
 *
 * @author Gokhan.Yavas
 */
@Parameters(commandDescription = "Contig Generate command type 1 with given coordinates of contigs on the reference as input")
public class ContigGenerateCommand1 extends Command{
    @Parameter(names = {"-f","--infile"}, description = "Input reference file path", required = true, converter = FileConverter.class)            
    protected File inputFile;
    @Parameter(names = {"-o","--outfile"}, description = "Output contig file path", required = false, converter = FileConverter.class)            
    protected File outputFile=new File("contigs.fa");                
    @Parameter(names = {"-c","--contigcoordsfile"}, description = "Input contig coords", required = true, converter = FileConverter.class)            
    protected File inputContigCoordsFile=null;    


    protected File destinationFolder=new File(System.getProperty("user.dir"));

    public File getInputContigCoordsFile() {
        return inputContigCoordsFile;
    }
    
        
    public ContigGenerateCommand1(){
        rcmd = RunCommand.ContigGenerate1;
    }    
    public File getOutputFile(){
        return outputFile;
    }

    public File getInputFile() {
        return inputFile;
    }


    public File getDestinationFolder() {
        return destinationFolder;
    }


}
