package org.fda.graphdrawing;

/**
 *
 * @author Linlin.Zhao
 */

public enum ImageFormat {
    
    pdf(".pdf"), jpeg(".jpeg"), png(".png");
    private final String fileExtension;
    ImageFormat(String f){
        fileExtension = f;
    }
    public String getExtension(){
        return fileExtension;
    }
}
