
package org.fda.functionality;

import com.beust.jcommander.IParameterValidator;
import com.beust.jcommander.ParameterException;

/**
 *
 * @author Gokhan.Yavas
 */
public class PositiveReal implements IParameterValidator{

    @Override
    public void validate(String name, String value) throws ParameterException {
        double n = Double.parseDouble(value);
        if (n < 0 ) {
            throw new ParameterException("Parameter " + name + " should be larger than 0 (found " + value +")");
        }
    }
    
}
