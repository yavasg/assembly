
package org.fda.functionality;

import com.beust.jcommander.IStringConverter;
import org.fda.data.Enums.ScriptRunMode;

/**
 *
 * @author Gokhan.Yavas
 */
public class ScriptRunModeConverter implements IStringConverter<ScriptRunMode>{

    @Override
    public ScriptRunMode convert(String value) {
        return ScriptRunMode.valueOf(value);
    }
    
}
