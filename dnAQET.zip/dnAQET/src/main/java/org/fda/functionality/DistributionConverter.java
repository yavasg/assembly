
package org.fda.functionality;

import com.beust.jcommander.IStringConverter;
import org.fda.data.Enums.Distribution;

/**
 *
 * @author Gokhan.Yavas
 */
public class DistributionConverter implements IStringConverter<Distribution>{

    @Override
    public Distribution convert(String value) {
        return Distribution.valueOf(value);
    }
    
}
