package org.fda.functionality;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import org.fda.regression.RegressionModel;

/**
 *
 * @author Gokhan.Yavas
 */
public class ShowModel {
    public static String getModelDetails(File infile) {
        RegressionModel rm=null;
        try{
            FileInputStream file1 = new FileInputStream(infile);
            BufferedInputStream bin = new BufferedInputStream(file1);
            ObjectInputStream in = new ObjectInputStream(bin);

            rm  = (RegressionModel)in.readObject();
        }
        catch(FileNotFoundException e){e.printStackTrace();}
        catch(IOException e){e.printStackTrace();}
        catch(ClassNotFoundException e){e.printStackTrace();}
            
        if(rm!=null)
            return(rm.toString());        
        else
            return null;
    }    
}
