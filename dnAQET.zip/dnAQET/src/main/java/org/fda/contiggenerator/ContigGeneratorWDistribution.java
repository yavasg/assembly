package org.fda.contiggenerator;

import java.io.File;
import java.util.Random;
import org.apache.commons.math3.distribution.GammaDistribution;
import org.apache.commons.math3.random.RandomGeneratorFactory;
import org.apache.commons.math3.random.RandomGenerator;
import org.fda.data.Utilities;
import org.fda.data.Enums.Distribution;

/**
 *
 * @author Gokhan.Yavas
 */
public abstract class ContigGeneratorWDistribution extends ContigGenerator{
    protected final Random rand;
    protected final GammaDistribution grand;
    protected double mean;
    protected double sd;
    protected final Distribution dist;
    protected boolean setseed=false;

    public double getMean() {
        return mean;
    }

    public double getSd() {
        return sd;
    }

    public void setMean(double mean) {
        this.mean = mean;
    }

    public void setSd(double sd) {
        this.sd = sd;
    }
    
    
    public ContigGeneratorWDistribution(File infile, File outfile, double mean, double sd, Distribution dist){
        super(infile, outfile);
        this.dist = dist;
        this.mean = mean;
        this.sd = sd;
        rand = new Random();
        if(dist==Distribution.GAMMA){
            RandomGenerator r = RandomGeneratorFactory.createRandomGenerator(rand);
            grand = new GammaDistribution(r, this.sd, this.mean);
        }
        else{
            grand=null;
        }
        
    }
    
    public ContigGeneratorWDistribution(File infile, File outfile, double mean, double sd, Distribution dist, boolean createreport){
        super(infile, outfile, createreport);
        this.dist = dist;
        this.mean = mean;
        this.sd = sd;
        rand = new Random();
        if(dist==Distribution.GAMMA){
            RandomGenerator r = RandomGeneratorFactory.createRandomGenerator(rand);
            grand = new GammaDistribution(r, this.sd, this.mean);
        }
        else{
            grand=null;
        }
        
    }
    
    public ContigGeneratorWDistribution(File infile, File outfile, double mean, double sd, Distribution dist, long seed){
        super(infile, outfile);
        this.dist = dist;
        this.mean = mean;
        this.sd = sd;
        rand = new Random(seed);
        if(dist==Distribution.GAMMA){
            RandomGenerator r = RandomGeneratorFactory.createRandomGenerator(rand);
            grand = new GammaDistribution(r, this.sd, this.mean);
        }
        else{
            grand=null;
        }
        
    }
    public ContigGeneratorWDistribution(File infile, File outfile, double mean, double sd, Distribution dist, long seed, boolean createreport){
        super(infile, outfile, createreport);
        this.dist = dist;
        this.mean = mean;
        this.sd = sd;
        rand = new Random(seed);
        if(dist==Distribution.GAMMA){
            RandomGenerator r = RandomGeneratorFactory.createRandomGenerator(rand);
            grand = new GammaDistribution(r, this.sd, this.mean);
        }
        else{
            grand=null;
        }        
    }
    
    public ContigGeneratorWDistribution(File infile, File outfile, double mean, double sd, Distribution dist, boolean setseed, boolean createreport){
        this(infile, outfile, mean, sd, dist, createreport);
        this.setseed=setseed;        
    }
    
    
    private int getGammaDistRandomLength(){
        int contlen;
        while(true){
            contlen = (int)grand.sample();
            if(contlen>Utilities.simulation_mincontiglength)
                break;                                        
        }
        
        return contlen;
    }
    private int getNormalDistRandomLength(){                
        int contlen;        
        while(true){
            contlen = (int)Math.round(rand.nextGaussian()*this.sd+this.mean);
            if(contlen>Utilities.simulation_mincontiglength)
                break;                                        
        }
        return contlen;
    }
    private int getUniformDistRandomLength(){                
        int contlen;        
        while(true){
            contlen = rand.nextInt((int)this.mean+1);
            if(contlen>Utilities.simulation_mincontiglength)
                break;                                        
        }
        return contlen;
    }
    
    protected int getRandomLength(){
        if(null==dist)
            return getUniformDistRandomLength();
        else switch (dist) {
            case NORMAL:
                return getNormalDistRandomLength();
            case GAMMA:
                return getGammaDistRandomLength();
            default:
                return getUniformDistRandomLength();
        }
    }                
    
}
