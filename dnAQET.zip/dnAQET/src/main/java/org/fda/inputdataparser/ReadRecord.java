
package org.fda.inputdataparser;


/**
 *
 * @author Gokhan.Yavas
 */
public abstract class ReadRecord {
    protected String header;
    protected String read;
    protected String name;
    protected int gc_count=0;
    protected double gc_percent=0;
    protected int ncount=0;
    protected double nratio=0;

    public void setName(String name){
        this.name = name;
    }
    public int getNcount() {
        return ncount;
    }

    public double getNratio() {
        return nratio;
    }
    
    public int getGCcount(){
        return gc_count;
    }   
    public double getGCpercent(){
        return gc_percent;
    }   
    
    public int getReadRecordLength(){
        return read.length();
    }
    public String getHeader(){
        return this.header;
    } 
    public String getName(){
        return this.name;
    } 
    
    public String getRead(){
        return this.read;
    }
    public abstract String toString();
    
}
