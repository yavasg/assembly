#create two models using two different alingment options
java -jar ../../dnAQET.jar model -r ../sample_genome.fa -d MODELMINIMAP
java -jar ../../dnAQET.jar model -r ../sample_genome.fa -d MODELNUCMER -q nucmer