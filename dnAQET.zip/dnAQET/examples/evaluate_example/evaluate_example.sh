#evaluate the sample genome against itself
java -jar ../../dnAQET.jar evaluate -f ../sample_genome.fa -r ../sample_genome.fa -n 1 -d RESULTSMINIMAP
java -jar ../../dnAQET.jar evaluate -f ../sample_genome.fa -r ../sample_genome.fa -n 2 -d RESULTSNUCMER -q nucmer