#evaluate the sample genome against itself
java -jar ../../dnAQET.jar evaluate -f ../sample_genome.fa -r ../sample_genome.fa -d INITIAL_RESULT

# reevaluate the results with modified parameters such as increased length scaling factor (which will penalize smaller contigs more), decreased threshold for RELOCATION
# type misassemblies (which may increase the number of misassemblies) 
java -jar ../../dnAQET.jar reevaluate -s INITIAL_RESULT -d UPDATED_RESULT -m 100 -l 1000000