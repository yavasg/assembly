package org.fda.evaluator;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import org.fda.regression.RegressionModel;
import org.fda.regression.RegressionModule;

/**
 *
 * @author Gokhan.Yavas
 */
public class Reevaluator4Artifact {
    private final File infile;
    private final File outfile;
    
    public Reevaluator4Artifact(File infile, File outfile){
        this.infile = infile;
        this.outfile = outfile;
        
    }
    public void process(){
        RegressionModel rm=null;
        try(ObjectInputStream instream = new ObjectInputStream(new BufferedInputStream(new FileInputStream(infile)));){
            rm = (RegressionModel)instream.readObject();
        }
        catch(ClassNotFoundException e){e.printStackTrace();}
        catch (IOException ex) {
            if(!(ex instanceof EOFException))
                ex.printStackTrace();
        }
        
        RegressionModel rm_new = RegressionModule.process(rm.getAlldatamap(), rm.getReferenceSet());
        try(ObjectOutputStream out = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(this.outfile))); ){
            out.writeObject(rm_new);
        }
        catch(IOException e){e.printStackTrace();}    
        
    }
}
