package org.fda.contiggenerator;

/**
 *
 * @author Gokhan.Yavas
 */
public interface ContigGeneratorInterface {
    public void generateContigs();
}
