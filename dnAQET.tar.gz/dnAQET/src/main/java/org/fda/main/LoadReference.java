package org.fda.main;

import java.io.BufferedInputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.Arrays;
import org.fda.alignment.ScaffoldContig;
import org.fda.data.Reference;
import org.fda.data.ReferenceSet;
import org.fda.data.Utilities;

/**
 *
 * @author Gokhan.Yavas
 */
public class LoadReference {
    public static void main(String[] args){
        ObjectInputStream ois1=null;
        ObjectInputStream ois2=null;
        try{
            ois1 = new ObjectInputStream(new BufferedInputStream(new FileInputStream("references.bin")));
            ReferenceSet refsetfull=(ReferenceSet)ois1.readObject();
//            ois2 = new ObjectInputStream(new BufferedInputStream(new FileInputStream(new File("scaffold_stats.bin"))));
//            ois2.readInt();
//            ScaffoldContig a=(ScaffoldContig)ois2.readObject();
//            //System.out.println(Utilities.byteToHex(a.getSeqHashValue()));
//            for(byte b : a.getSeqHashValue())
//                System.out.print(b);
//            System.out.println();
//            Reference q = refsetfull.findReference("chrX");
//            //System.out.println(Utilities.byteToHex(q.getSeqHashValue()));
//            for(byte b : q.getSeqHashValue())
//                System.out.print(b);
//            System.out.println(Utilities.ls+Arrays.equals(a.getSeqHashValue(), q.getSeqHashValue()));
            
            for(Reference r : refsetfull.getRefs()){
                String name = r.getRefID();
                System.out.println("Name: "+r.getRefID());
//                System.out.println("HashCode1: "+Utilities.byteToHex(r.getSeqHashValue()));
//                System.out.println("GCrat: "+r.getGCpercent());
//                //System.out.println("Size: "+r.getLength());
//                
//                for(Reference q : refsetfull.getRefs()){
//                    if(q.getRefID().equalsIgnoreCase(name)){
//                        System.out.println("HashCode2: "+Utilities.byteToHex(q.getSeqHashValue()));
//                        System.out.println("GCrat: "+q.getGCpercent());
//                        //System.out.println("Size: "+q.getLength());
//                    }
//                }
//                
            }
            
            
//            ois = new ObjectInputStream(new BufferedInputStream(new FileInputStream("OUT/bin/references.bin")));
//            ReferenceSet refset=(ReferenceSet)ois.readObject();
//            
//            ois = new ObjectInputStream(new BufferedInputStream(new FileInputStream("model.bin")));
//            RegressionModel rm = (RegressionModel)ois.readObject();
//            if(rm.getReferenceSet().contains(refset_partial)){
//                System.out.println("Contains1");
//            }
//            if(rm.getReferenceSet().contains(refset)){
//                System.out.println("Contains2");
//            }
            
//            for(Reference r : rm.getReferenceSet().getRefs()){
//                System.out.println(r.getRefID());
//                System.out.println(Utilities.byteToHex(r.getHashValue()));
//                System.out.println(Utilities.bytesToHex(r.getHashValue()));
//                for(byte b : r.getHashValue())
//                    System.out.print(b + " ");
//                System.out.println();
//            }
//            System.out.println("");
//            for(Reference r : refset_partial.getRefs()){
//                System.out.println(r.getRefID());
//                System.out.println(Utilities.byteToHex(r.getHashValue()));
//                System.out.println(Utilities.bytesToHex(r.getHashValue()));
//                for(byte b : r.getHashValue())
//                    System.out.print(b + " ");
//                System.out.println();
//                
//            }
            
            
            
//            ReferenceSet refsetfull = new ReferenceSet(new File("hg38.fa"), new File("OUT1"));
//            ReferenceSet refset_partial = new ReferenceSet(new File("chr21_22_X_Y.fa"), new File("OUT2"));
//            if(refsetfull.contains(refset_partial)){
//                System.out.println("Contains");
//            }
            

        }
        catch(ClassNotFoundException e){e.printStackTrace();}
        catch (IOException ex) {

            if(!(ex instanceof EOFException))
                ex.printStackTrace();
        }            
        finally {
            try {
                ois1.close();
                //ois2.close();
            } catch (IOException ex) {
                    ex.printStackTrace();                    
            }
        } 
        
        
    }
}
