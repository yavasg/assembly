
package org.fda.exceptions;

/**
 *
 * @author Gokhan.Yavas
 */
public class IllegalIntervalException extends Exception{
    public IllegalIntervalException(){}
    public IllegalIntervalException(String message){
        super(message);
    }
    public IllegalIntervalException(Throwable cause){
        super(cause);
    }
    public IllegalIntervalException(String message, Throwable cause){
        super(message, cause);
    }
    public IllegalIntervalException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace){
        super(message, cause, enableSuppression, writableStackTrace);
    }
    
}
