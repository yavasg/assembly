
package org.fda.exceptions;

/**
 *
 * @author Gokhan.Yavas
 */
public class ImageFileFormatNotFoundException extends Exception{
    public ImageFileFormatNotFoundException(){}
    public ImageFileFormatNotFoundException(String message){
        super(message);
    }
    public ImageFileFormatNotFoundException(Throwable cause){
        super(cause);
    }
    public ImageFileFormatNotFoundException(String message, Throwable cause){
        super(message, cause);
    }
    public ImageFileFormatNotFoundException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace){
        super(message, cause, enableSuppression, writableStackTrace);
    }
    
}
