
package org.fda.multithreading;

import java.util.concurrent.BlockingQueue;

/**
 *
 * @author Gokhan.Yavas
 */
public class ScriptRunner implements Runnable{
    private BlockingQueue queue;

    public ScriptRunner(BlockingQueue queue){
        this.queue = queue;
    }
    @Override
    public void run() {
        Object runcmd;
        Runtime r = Runtime.getRuntime();
        while(true){
            try{
                runcmd = queue.take();
                if(runcmd instanceof String){
//                    System.out.println("Running job: "+runcmd);
                    Process p = r.exec((String) runcmd);            
                    p.waitFor();            
//                    System.out.println("Finished job: "+runcmd);
                }    
                else
                    break;
            }
            catch(Exception ex){/* Do nothing about it*/ ex.printStackTrace();}            
        }
    }        
}
