
package org.fda.functionality;

import com.beust.jcommander.IStringConverter;
//import org.fda.data.Enums.ModelComputeMode;

/**
 *
 * @author Gokhan.Yavas
 */
//public class ModelComputeModeConverter implements IStringConverter<ModelComputeMode>{
public class ModelComputeModeConverter{

//    @Override
//    public ModelComputeMode convert(String value) {
//        return ModelComputeMode.valueOf(value);
//    }
    
}
