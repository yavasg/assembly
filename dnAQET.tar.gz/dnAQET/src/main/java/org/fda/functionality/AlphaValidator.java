
package org.fda.functionality;

import com.beust.jcommander.IParameterValidator;
import com.beust.jcommander.ParameterException;

/**
 *
 * @author Gokhan.Yavas
 */
public class AlphaValidator implements IParameterValidator{

    @Override
    public void validate(String name, String value) throws ParameterException {
        double n = Double.parseDouble(value);
        if (n < 0 || n >1) {
            throw new ParameterException("Parameter " + name + " should be between 0 and 1 (found " + value +")");
        }
    }
    
}
