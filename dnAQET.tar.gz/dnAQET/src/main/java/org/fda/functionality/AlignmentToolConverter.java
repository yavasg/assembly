
package org.fda.functionality;

import com.beust.jcommander.IStringConverter;
import org.fda.data.Enums.AlignmentTool;


/**
 *
 * @author Gokhan.Yavas
 */
public class AlignmentToolConverter implements IStringConverter<AlignmentTool>{
//public class AlignmentToolConverter {

    @Override
    public AlignmentTool convert(String value) {
        return AlignmentTool.valueOf(value);
    }
    
}
