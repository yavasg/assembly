package org.fda.commands;

import com.beust.jcommander.Parameter;
import com.beust.jcommander.Parameters;
import com.beust.jcommander.converters.FileConverter;
import java.io.File;
import org.fda.data.Enums;

/**
 *
 * @author Gokhan.Yavas
 */
@Parameters(commandDescription = "Pick the chromosomes from a fasta file to create a new fasta file")
public class ChrPickerCommand extends Command{
    @Parameter(names = {"-i"}, description = "Input reference file path", required = true, converter = FileConverter.class)            
    protected File inputFile;
    @Parameter(names = {"-o"}, description = "Output file path", required = true, converter = FileConverter.class)            
    protected File outFile;
    @Parameter(names = {"-l"}, description = "List of chromosomes to pick", required = true, converter = FileConverter.class)            
    protected File chrFile;
    
    protected File destinationFolder=new File(System.getProperty("user.dir"));
    public ChrPickerCommand(){
        this.rcmd = Enums.RunCommand.ChrPick;
    }
    public File getInputFile() {
        return inputFile;
    }

    public File getOutFile() {
        return outFile;
    }

    public File getChrFile() {
        return chrFile;
    }
}
