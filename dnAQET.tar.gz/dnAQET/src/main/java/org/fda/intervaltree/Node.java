/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.fda.intervaltree;

import java.io.Serializable;

/**
 *
 * @author Gokhan.Yavas
 */
public class Node implements Serializable {
    private static final long serialVersionUID = 112414357102382689L;
    
    Interval interval;      // key        
    Node left, right;         // left and right subtrees
    int N;                    // size of subtree rooted at this node
    int max;                  // max endpoint in subtree rooted at this node

    Node(Interval interval) {
        this.interval = interval;
        this.N        = 1;
        this.max      = interval.gethigh();
    }
}
