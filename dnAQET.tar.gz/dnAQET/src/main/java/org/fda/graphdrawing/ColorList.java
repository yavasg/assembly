
package org.fda.graphdrawing;

import java.awt.Color;

/**
 *
 * @author Linlin.Zhao
 */

public class ColorList {
    
    private Color[] colors;
    
    public ColorList(){
         Color[] cols = {Color.GREEN,Color.BLUE,Color.RED,Color.GRAY,Color.ORANGE,Color.YELLOW,Color.MAGENTA,Color.CYAN,Color.PINK,Color.BLACK,Color.DARK_GRAY,Color.LIGHT_GRAY};
         this.colors = cols;
    }
    
    public ColorList(Color[] ca){
        this.colors = ca;
    }
    
    public void setColors(Color[] cb){
        this.colors = cb;
    }
    
    public Color[] getColors(){
        return this.colors;
    }
}
